-- 현재 Sequence 값
SELECT content_seq.nextval FROM DUAL;

SELECT * FROM user_table;

SELECT * FROM content_table
 WHERE content_idx = 38;
 
UPDATE content_table 
   SET content_subject = '유머', content_text='유머유머유머유머', content_file='test.jpg' 
 WHERE content_idx = 38;


DELETE FROM content_table 
      WHERE content_idx = 38; 


-- 전체 글 개수
SELECT count(*) FROM content_table
 WHERE content_board_idx = 1;

SELECT * FROM content_table;

SELECT count(*) FROM content_table
 WHERE content_board_idx = 2;
 
SELECT count(*) FROM content_table
 WHERE content_board_idx = 3;
 
SELECT count(*) FROM content_table
 WHERE content_board_idx = 4; 







