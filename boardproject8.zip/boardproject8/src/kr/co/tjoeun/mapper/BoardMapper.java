package kr.co.tjoeun.mapper;

public interface BoardMapper {

}
