package kr.co.tjoeun.bean;

import lombok.Data;

// board_info_table
@Data
public class BoardInfoBean {
  private int board_info_idx;
  private String board_info_name;
  
}
